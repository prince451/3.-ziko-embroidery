<?php

include('../includes/config.php');

if(isset($_GET['action']) && $_GET['action'] == 'get'){

   $id = intval($_GET['id']);


}



if(isset($_POST['action']) && $_POST['action'] == 'delete'){

    $id = intval($_POST['id']);


    $sql = "SELECT * FROM emb_details WHERE id = '$id'";
    $run = mysqli_query($conn, $sql);
    $row2 = mysqli_fetch_assoc($run);

    if($row2['emb_image'] && file_exists('uploads/' . $row2['emb_image'])){

        unlink('uploads/' . $row2['emb_image']);
    
    }
    

    $stmt = $conn->prepare("DELETE FROM emb_details WHERE id = ?");
    $stmt->bind_param("i", $id);

    if($stmt->execute()){

        echo "success";

    }else{

        echo "delete failed";
    }

    $stmt->close();
    $conn->close();
}


?>