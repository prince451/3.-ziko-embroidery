<?php

include_once('../includes/config.php');

$search = $_POST['search'];

$stmt = $conn-prepare("SELECT id, party_name FROM party_details WHERE party_name LIKE ? LIMIT 10");

$search = "%" . $search . "%";

$stmt->bind_param('s', $search);
$stmt->execute();

$result = $stmt->get_result();

$parties = [];

while($row = $result->fetch_assoc()){
   
 $parties[] = $row;
   
}

echo json_encode($parties);


?>