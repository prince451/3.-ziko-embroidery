<?php 

include('../includes/config.php');

if(isset($_GET['action']) && $_GET['action'] == 'get'){

    $id = intval($_GET['id']);

    $result = mysqli_query($conn, "SELECT e.*, p.party_name, v.vendor_name
    FROM emb_details e
    LEFT JOIN party_details p ON e.party_id = p.id
    LEFT JOIN vendor_details v ON e.vendor_code = v.id
    WHERE e.id = '$id'");

    $emb = mysqli_fetch_assoc($result);

    echo json_encode($emb);
    exit;
}


// YAHAN POST UPDATE CODE

if(isset($_POST['action']) && $_POST['action'] == 'update'){

    $id = intval($_POST['id']);

    if(isset($_FILES['emb_image']) && !empty($_FILES['emb_image']['name'])){

        $embFile = $_FILES['emb_image'];

        $extension = strtolower(pathinfo($embFile['name'], PATHINFO_EXTENSION));

        $fileName = 'emb-' . bin2hex(random_bytes(8)) . '.' . $extension;

        if(move_uploaded_file($embFile['tmp_name'], 'uploads/' . $fileName)){

            $result = mysqli_query($conn,
                "SELECT emb_image FROM emb_details WHERE id = '$id'"
            );

            $oldData = mysqli_fetch_assoc($result);
            $oldImage = $oldData['emb_image'];

            if(!empty($oldImage) && file_exists('uploads/' . $oldImage)){
                unlink('uploads/' . $oldImage);
            }

            mysqli_query($conn,
                "UPDATE emb_details
                 SET emb_image = '$fileName'
                 WHERE id = '$id'"
            );

            echo "success";
        }
    }

    exit;
}

?>