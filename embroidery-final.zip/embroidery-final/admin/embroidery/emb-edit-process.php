<?php 

include('../includes/config.php');


// GET DATA FOR EDIT
if(isset($_GET['action']) && $_GET['action'] == 'get'){

    $id = intval($_GET['id']);

    $result = mysqli_query($conn, "SELECT e.*, p.party_name, v.vendor_name
    FROM emb_details e
    LEFT JOIN party_details p ON e.party_id = p.id
    LEFT JOIN vendor_details v ON e.vendor_code = v.id
    WHERE e.id = '$id'");

    $emb = mysqli_fetch_assoc($result);

    echo json_encode($emb);

    exit;
}


// UPDATE DATA
if(isset($_POST['action']) && $_POST['action'] == 'update'){

    $id = intval($_POST['id']);

    $party_id = intval($_POST['party_id']);
    $emb_code = mysqli_real_escape_string($conn, $_POST['emb_code']);
    $shoe_color = mysqli_real_escape_string($conn, $_POST['shoe_color']);
    $vendor = intval($_POST['vendor']);

    $po_link = mysqli_real_escape_string($conn, $_POST['po_link']);

    $emb_process_date = mysqli_real_escape_string($conn, $_POST['emb_process_date']);
    $emb_recieve_date = mysqli_real_escape_string($conn, $_POST['emb_recieve_date']);
    $po_generate_date = mysqli_real_escape_string($conn, $_POST['po_generate_date']);

    $emb_number = intval($_POST['emb_number']);
    $per_piece_price = mysqli_real_escape_string($conn, $_POST['per_piece_price']);

    $remarks = mysqli_real_escape_string($conn, $_POST['remarks']);


    // CHECK NEW IMAGE
    if(isset($_FILES['emb_image']) && !empty($_FILES['emb_image']['name'])){

        $embFile = $_FILES['emb_image'];

        $extension = strtolower(pathinfo($embFile['name'], PATHINFO_EXTENSION));

        $fileName = 'emb-' . bin2hex(random_bytes(8)) . '.' . $extension;


        if(move_uploaded_file($embFile['tmp_name'], 'uploads/' . $fileName)){

            // GET OLD IMAGE
            $result = mysqli_query($conn,
                "SELECT emb_image FROM emb_details WHERE id = '$id'"
            );

            $oldData = mysqli_fetch_assoc($result);

            $oldImage = $oldData['emb_image'];


            // DELETE OLD IMAGE
            if(!empty($oldImage) && file_exists('uploads/' . $oldImage)){
                unlink('uploads/' . $oldImage);
            }


            // UPDATE ALL DATA + NEW IMAGE
            mysqli_query($conn,
                "UPDATE emb_details SET
                    party_id = '$party_id',
                    emb_design_code = '$emb_code',
                    shoes_color_name = '$shoe_color',
                    vendor_code = '$vendor',
                    emb_image = '$fileName',
                    po_link = '$po_link',
                    emb_process_date = '$emb_process_date',
                    emb_recieve_date = '$emb_recieve_date',
                    po_generate_date = '$po_generate_date',
                    total_no_emb = '$emb_number',
                    per_pcs_price = '$per_piece_price',
                    remarks = '$remarks'
                 WHERE id = '$id'"
            );

            echo "success";

        } else {

            echo "Image upload failed";

        }

    } else {

        // UPDATE ALL DATA WITHOUT CHANGING IMAGE
        mysqli_query($conn,
            "UPDATE emb_details SET
                party_id = '$party_id',
                emb_design_code = '$emb_code',
                shoes_color_name = '$shoe_color',
                vendor_code = '$vendor',
                po_link = '$po_link',
                emb_process_date = '$emb_process_date',
                emb_recieve_date = '$emb_recieve_date',
                po_generate_date = '$po_generate_date',
                total_no_emb = '$emb_number',
                per_pcs_price = '$per_piece_price',
                remarks = '$remarks'
             WHERE id = '$id'"
        );

        echo "success";
    }

    exit;
}

?>