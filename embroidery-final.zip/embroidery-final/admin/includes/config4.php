<?php 
// Report all errors except warnings, notices, and deprecations
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

// Ensure errors are not printed out to the browser
ini_set('display_errors', '0');

// (Optional) Log the hidden errors to a private file instead
ini_set('log_errors', '1');

?>



<?php

$serverName = "localhost";
$username = "root";
$password = "";
$database = "emb_final";

//create connection

$conn = new mysqli($serverName,$username,$password,$database);

// checking connection 

if($conn->mysqli_error){

  die('Failed to connect ' . $conn->mysqli_error);

}else{

  // echo "<script>alert('Connection Success !')</script>";


}






?>