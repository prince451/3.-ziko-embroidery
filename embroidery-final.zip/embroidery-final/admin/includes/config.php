php
<?php
// 1. Enter your exact Aiven credentials here
$host     = "mysql-3db3cae3-ziko-emb-project.h.aivencloud.com";     // Paste the clean hostname (do NOT include http:// or mysql://)
$user     = "avnadmin";                 // Your Aiven username
$password = "AVNS_goHjkwerNIP8C4r6W7W"; // Your long Aiven password
$database = "emb_final";                // Your Aiven database name
$port     = "22926";     // The 5-digit number from Aiven

// 2. Initialize MySQLi
$conn = mysqli_init();

if (!$conn) {
    die("MySQLi initialization failed");
}

// 3. Set the SSL Certificate (Notice there are NO '//' marks here anymore. This is now active!)
mysqli_ssl_set($conn, NULL, NULL, __DIR__ . "/ca.pem", NULL, NULL);

// 4. Connect to the Aiven Cloud Server strictly over SSL
$real_connect = mysqli_real_connect(
    $conn, 
    $host, 
    $user, 
    $password, 
    $database, 
    $port, 
    NULL, 
    MYSQLI_CLIENT_SSL // Forces the required secure connection
);

if (!$real_connect) {
    die("Cloud Database Connection Failed: " . mysqli_connect_error());
}

// If it works, you will see this text in your browser
echo "Successfully connection";