<?php
session_start();


include('../includes/config.php');

if(isset($_POST['submit'])){



if(!empty($_POST['fullname'])) { 

 $fullName = trim($_POST['fullname']);

}


if(!empty($_POST['email'])){
 $email = trim($_POST['email']);



}


if(!empty($_POST['mobile'])){

 $mobile = trim($_POST['mobile']);

}


if(!empty($_POST['password'])){

 $password = trim($_POST['password']);

 $hash = password_hash($password, PASSWORD_DEFAULT);

}


 $createdAt = date('Y-m-d H:i:s');


$stmt = $conn->prepare("INSERT INTO `user_details`(`name`, `email`, `mobile`, `password`, `created_at`, `created_by`) VALUES (?,?,?,?,?,?)");

$stmt->bind_param("ssssss", $fullName, $email, $mobile, $hash, $createdAt, $fullName);

// $stmt->execute();


if($stmt->execute()){

  $_SESSION['data'] = "<h4 class='alert alert-success' role='alert' style='color:green;text-align:center;'>You are registered  Successfully ! $fullName </h4>";
 
   header('location:../register.php');

}else{  

  $_SESSION['data'] = "<h3 style='color:red;text-align:center'>Failed to insert !</h3>";
 
   header('location:../register.php');
     
}

$stmt->close();







// $sql = "INSERT INTO `user_details`(`name`, `email`, `mobile`, `status`, `password`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES ('$fullName','$email','$mobile','','$hash',now() ,'$fullName','','')";

// $run = mysqli_query($conn, $sql);

// if($run){

// header('location:../register.php');

   
// }else{

// header('location:../register.php');


// location('header:../register.php');

// }  

}


?>




