<?php

include_once('../includes/config.php');

if(isset($_POST['submit'])){

//    echo "<script>alert('Everything is ok')</script>";

  if(!empty($_POST['psw'])){

       $psw = $_POST['psw'];
      
      
     echo $hashPsw;

 }

echo "<br><br>";

if(!empty($_POST['confirm-psw'])){

     $confirPsw = $_POST['confirm-psw'];


 }

 if($psw === $confirPsw){ 

     $hashPsw = password_hash($psw, PASSWORD_DEFAULT);

     $sql = "UPDATE user_details SET password = '$hashPsw'";
     $run = mysqli_query($conn, $sql);

      if($run){

        //  header('location:reset-password.php');
         
         echo "<h5>Password Reset Success</h5>";
         
         
      }else{

    //    header('location:reset-password.php');

         echo "<h5>Failed to Update, Something error</h5>";
         
      }

     
 }


}




?>