<?php

include('../includes/config.php');


$email = $_POST['email'];

$sql = "SELECT * FROM user_details WHERE email = '$email'";

$run = mysqli_query($conn, $sql);

echo json_encode(["exists"=> mysqli_num_rows($run) > 0]);


?>