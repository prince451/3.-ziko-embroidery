<?php


if(isset($_POST['submit'])){

if(!empty($_POST['newId'])){

   echo $id = $_POST['newId']; 
}


if(!empty($_POST['ufullname'])){

  echo $uname = $_POST['ufullname'];
}


if(!empty($_POST['uemail'])){

 echo $uemail = $_POST['uemail'];

   
}

$upadateAt = date('Y-m-d H:i:s');


if(!empty($_POST['umobile'])){

   echo $umobile = $_POST['umobile'];
}

include('../includes/config.php');

 $userEmail = $_SESSION['email'] ; 

                //  echo $userEmail;
                 
$userEmail;


// to get logged in user details
$sql = "SELECT * FROM user_details WHERE email = '$userEmail'";
$run = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($run);

$fetchUserId = $row['id'];
$fetchUserName = ucfirst($row['name']);



// to update user details

$stmt = $conn->prepare("UPDATE user_details SET name = ?, email = ?, mobile = ?, updated_at = ?, updated_by = ? WHERE id = ?");
$stmt->bind_param("sssssi", $uname, $uemail, $umobile, $upadateAt, $fetchUserName, $id);
if($stmt->execute()){

  $stmt->close();
  $conn->close();

  header('location:../list-users.php');

}else{

   echo "Error " . $stmt->error();
}

    
}





?>