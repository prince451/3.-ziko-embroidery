<?php

include('../includes/config.php');

$mobile = $_POST['mobile'];

$sql = "SELECT * FROM user_details WHERE mobile = '$mobile'";
$run = mysqli_query($conn, $sql);

echo json_encode(["exists" => mysqli_num_rows($run) > 0]);



?>