<?php
session_start();

include_once('../includes/config.php');

if(isset($_POST['submit'])){

//    echo "<script>alert('success');</script>";

if(!empty($_POST['email'])){

echo $email = $_POST['email'];


$sql2 ="SELECT * FROM user_details WHERE email = '$email'";
$run2 = mysqli_query($conn, $sql2);
$count = mysqli_num_rows($run2) > 0;

if($count){

   header('location:reset-password.php');

}else{

   header('location:forget-password.php');
}




}

}



?>