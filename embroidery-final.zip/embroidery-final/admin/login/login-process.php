<?php
session_start();


include('../includes/config.php');

if(isset($_POST['submit'])){

echo "<script>alert('success');</script>";

if(!empty($_POST['email'])){

  $email = $_POST['email'];

  $_SESSION['email'] = $_POST['email'];
}


if(!empty($_POST['psw'])){

     $password = $_POST['psw'];
    echo "<br>";
    
     $hash = password_hash($password, PASSWORD_DEFAULT);
}



$sql ="SELECT * FROM user_details WHERE email = '$email'";
$run = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($run);

echo $hashPsw = $row['password'];

$count = mysqli_num_rows($run) > 0;
 echo "<br>";
 echo $count;



 if($count){

   if(password_verify($password, $hashPsw)){

        header('location:../dashboard.php');

   }else{
        
       header('location:../dashboard.php');

   }
 }

// $stmt = $conn->prepare("SELECT * FROM user_details WHERE email = '$email'");
// $stmt->bind_param("s", $email);

// $stmt->execute();

// $stmt->close();

}






?>