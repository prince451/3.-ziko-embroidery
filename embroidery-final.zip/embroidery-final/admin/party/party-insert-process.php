<?php

session_start();

include_once('../includes/config.php');

 //for getting logged in user details


     $userEmail = $_SESSION['email'] ; 

//  echo $userEmail;
                 
    $userEmail;

                

    $sql = "SELECT * FROM user_details WHERE email = '$userEmail'";
    $run = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($run);

    $fetchUserId = $row['id'];
    $fetchUserName = $row['name'];




// for inserting data into party table


$partyName = isset($_POST['partyName']) ? mysqli_real_escape_string($conn, $_POST['partyName']) : '';

$branch = isset($_POST['branch']) ? mysqli_real_escape_string($conn, $_POST['branch']): '';

if(!empty($branch)){
   
 $partyName =   $partyName . "-" . $branch;
   
}else{

  $paryName;

}


// adding for serial unique number for individual party


$prefix = "sl-";

// Last serial number nikalo
$query = "SELECT party_special_id 
          FROM party_details 
          WHERE party_special_id LIKE 'sl-%'
          ORDER BY id DESC 
          LIMIT 1";

$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if ($row) {
    // sl-00003 → 3
    $lastNumber = (int) str_replace($prefix, '', $row['party_special_id']);
    $number = $lastNumber + 1;
} else {
    // First submit
    $number = 1;
}

// New serial
$serialNumber = sprintf("%s%05d", $prefix, $number);

// echo $serialNumber;


 

$createdAt = date('Y-m-d H:i:s');

if(empty($partyName)){

  echo "Error: This field must be filled !";
  exit;

}


$stmt = $conn->prepare("INSERT INTO party_details (party_special_id, party_name, branch_location, created_at, created_by) VALUES(?, ?, ?, ?, ?)");

$stmt->bind_param("sssss", $serialNumber, $partyName, $branch, $createdAt, $fetchUserName);

if($stmt->execute()){

    echo "success";

}else{

    echo "Error : Something issue";

}
  

$stmt->close();

$conn->close();




?>