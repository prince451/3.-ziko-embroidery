<?php
include('../includes/config.php');

if(isset($_POST['action']) && $_POST['action'] == 'delete'){

$id = intval($_POST['id']);

$stmt = $conn->prepare("DELETE FROM party_details WHERE id = ?");
$stmt->bind_param("i", $id);

if($stmt->execute()){

    echo "success";
}else{

   echo "Deleted Failed";
}

$stmt->close();
$conn->close();

}


?>