<?php

include('../includes/config.php');

if(isset($_GET['action']) && $_GET['action'] == 'get'){

   $id = intval($_GET['id']);
   $stmt = $conn->prepare('SELECT * FROM party_details WHERE id = ?');
   $stmt->bind_param('i', $id);
   $stmt->execute();

   $result = $stmt->get_result();
   $party = $result->fetch_assoc();

   $stmt->close();
   $conn->close();

   echo json_encode($party);

   exit;



}


if(isset($_POST['action']) && $_POST['action'] == 'update'){

$id = intval($_POST['id']);
$partyName = isset($_POST['partyName']) ? $_POST['partyName'] : '';
$branch = isset($_POST['branch']) ? $_POST['branch'] : '';

if(!empty($branch)){
   
 $partyName =   $partyName . "-" . $branch;
   
}else{

  $paryName;

}

$stmt = $conn->prepare('UPDATE party_details SET party_name = ?, branch_location = ? WHERE id = ?');
$stmt->bind_param('ssi', $partyName, $branch, $id);
if($stmt->execute()){

    echo "success";
}else{

   echo "Error: " . mysqli_error($conn);
}

$stmt->close();
$conn->close();

}


?>